<?php namespace App\Models\Ctr;

use CodeIgniter\Model;

class NewsModel extends Model
{
	/*
	protected $db;

    public function __construct(ConnectionInterface &$db)
    {
        $this->db =& $db;
    }*/
	
	protected $table         = 'news';
    protected $primaryKey = 'cID';
    protected $allowedFields = [
        'cDay', 'cTitle', 'cContent'
    ];
    protected $returnType    = 'App\Entities\Ctr\NewsEntity';
    //protected $returnType    = 'object';
	
	public function get_list_model()
	{
		
		$result = $this->builder()->get();
		
		return $result;
	}
}