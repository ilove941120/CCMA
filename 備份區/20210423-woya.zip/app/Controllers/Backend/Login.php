<?php

namespace App\Controllers\Backend;

use App\Controllers\BaseController;

class Login extends BaseController
{
	var $login_success_goto;
	var $id = '1';
	var $password = '1';

	public function __construct(){
		// $this->_check_login();
        $this->login_success_goto = 'login';
	}
    public function index()
	{
		echo view('backend/login');
	}
	public function check_login()
	{
		if( $this->request->getPost('ID') == false ) die('操作錯誤');
		if( $this->request->getPost('ID') == $this->id && $this->request->getPost('Password') == $this->password)
		{
			$this->session->set('admin_login','login');
			header('location:' . base_url($this->login_success_goto) );
			die();
		}
		else
		{
			header('location:' . base_url('login1') );
			die();
		
			// echo view('backend/login');
		}


	}
    function logout()
	{
		$this->session->destroy();
		//header('location:'. base_url() .'/ctr/login');
		header('location:' . base_url('login1') );
	}
	
	//放在每一個需要登入的controller function __construct 中，
	private function _check_login()
	{
		if( session('admin_login') != 'login' )
		{
			header('location:' . base_url('login1') );
			//base_url('ctr/login');
            die();
		}
	}


}
?>