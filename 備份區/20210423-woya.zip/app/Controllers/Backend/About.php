<?php

namespace App\Controllers\Backend;

use App\Controllers\BaseController;

class About extends BaseController
{

	public function __construct(){
		$this->_check_login();
	}
	private function _check_login()
	{
		if( session('admin_login') != 'login' )
		{
			header('location:' . base_url('login1') );
			die();
		}
	}
    public function aboutPage(){
        $builder = $this->db->table("about");
		$query   = $builder->get(); 
		$results = $query->getResult();
        $date["about"] =$results;

		if(isset($_POST["action"])&&($_POST["action"]=="aboutText")){
			$data = [
				'aboutText' => $_POST["aboutText"],
			];
			$builder = $this->db->table("about")->update($data);
	        header("Location:" . base_url('Backend/About/aboutShow'));
            die();

		}
		return view('backend/aboutPage',$date);
    }
	public function aboutShow(){
        $builder = $this->db->table("about");
		$query   = $builder->get(); 
		$results = $query->getResult();
        $date["about"] =$results;

		if(isset($_POST["action"])&&($_POST["action"]=="aboutText")){
			$data = [
				'aboutText' => $_POST["aboutText"],
			];
			$builder = $this->db->table("about")->update($data);
	        header("Location:" . base_url('Backend/About/aboutShow'));
            die();

		}
		return view('backend/aboutShow',$date);
    }
	public function aboutShowSpirit(){
        $builder = $this->db->table("about");
		$query   = $builder->get(); 
		$results = $query->getResult();
        $date["about"] =$results;

		if(isset($_POST["action"])&&($_POST["action"]=="aboutText")){
			$data = [
				'aboutText' => $_POST["aboutText"],
			];
			$builder = $this->db->table("about")->update($data);
	        header("Location:" . base_url('Backend/About/aboutShowSpirit'));
            die();

		}
		return view('backend/aboutShowSpirit',$date);
    }


}
?>