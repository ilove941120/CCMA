<?php

namespace App\Controllers\Backend;

use App\Controllers\BaseController;

class News extends BaseController
{


	public function __construct(){
		$this->_check_login();
	}
	private function _check_login()
	{
		if( session('admin_login') != 'login' )
		{
			header('location:' . base_url('login1') );
			die();
		}
	}
    public function newsShow(){
		
        $builder = $this->db->table("news")->orderBy('cDay', 'DESC')->limit(99);
		$query   = $builder->get(); 
		$results = $query->getResult();
        
        $date["news"] =$results;
		return view('backend/newsShowpage',$date);
    }
	

	public function newInpage(){
		$i=$this->uri->getSegment(4,'all');
        $builder = $this->db->table("news")->where("cID=".$i);
		$query   = $builder->get(); 
		$results = $query->getResult();
        $date["news"] =$results;
		return view('backend/newInpage',$date);
    }
    public function newsAdd(){
		if(isset($_POST["action"])&&($_POST["action"]=="update")){
			$data = [
				'cTitle' => $_POST["cTitle"],
				'cDay' => $_POST["cDay"],
				'cContent' => $_POST["cContent"],
				'cImg' => $_POST["cImg"],
			];
			$builder = $this->db->table("news")->insert($data);
	        header("Location:" . base_url('Backend/News/newsShow'));
            die();

		}
		return view('backend/newAdd');
    }
    public function newsUpdate(){
		$i=$this->uri->getSegment(4,'all');
        $builder = $this->db->table("news")->where("cID=".$i);
		$query   = $builder->get(); 
		$results = $query->getResult();
        $date["news"] =$results;

		if(isset($_POST["action"])&&($_POST["action"]=="update")){
			$data = [
				'cTitle' => $_POST["cTitle"],
				'cDay' => $_POST["cDay"],
				'cContent' => $_POST["cContent"],
				// 'cImg' => $_POST["cImg"],

			];
			$builder = $this->db->table("news")->where("cID=".$i)->update($data);
	        header("Location:" . base_url('Backend/News/newsShow'));
            die();

		}
		return view('backend/newUpdate',$date);

    }
	public function newsDelete(){
		$i=$this->uri->getSegment(4,'all');
        $builder = $this->db->table("news")->where("cID=".$i);
		$query   = $builder->get(); 
		$results = $query->getResult();
        $date["news"] =$results;

		if(isset($_POST["action"])&&($_POST["action"]=="delete")){
			$builder = $this->db->table("news")->where("cID=".$i)->delete();
	        header("Location:" . base_url('Backend/News/newsShow'));
            die();
		}
		return view('backend/newDelete',$date);
    }
	public function ilist()
	{


        $builder = $this->db->table("news");

		$begin_date = $this->uri->setSilent()->getSegment(4,'all');	
		$last_date = $this->uri->setSilent()->getSegment(5,'all');
		$current_page = $this->uri->setSilent()->getSegment(6,1);

		//分頁設定值
        $limit = 5;
        $data_row = ($current_page - 1) * $limit;
        $base_url_segment = 'backend/news/ilist/'. $begin_date .'/'. $last_date;

		//列表資料
        if($begin_date != 'all') $builder->where('cDay >=', $begin_date);
		if($last_date != 'all') $builder->where('cDay <=', $last_date);
		//$builder = $builder->get('news',$limit, $data_row);
		$content['news'] = $builder->orderBy('cDay', 'desc')->limit($limit)->offset($data_row);
		// $content['news'] = $builder->orderBy('datetime', 'desc')->findAll($limit, $data_row);


		//列表數量
        if($begin_date != 'all') $builder->where('cDay >=', $begin_date);
		if($last_date != 'all') $builder->where('cDay <=', $last_date);

		
		// $results = $builder->getResult();
		$query = $builder->get();
		$results = $query->getResult();
        $content["news"] =$results;
		
		// die(var_dump($query));

		$total_rows = count($results);

        //分頁設定
		$this->pagination->setSegment(6);
		$this->pagination->setPath($base_url_segment);
        $content['pagination_link'] = $this->pagination->makeLinks($current_page, $limit, $total_rows, 'default_full', 6);
		$content['current_begin_date'] = ($begin_date == 'all' ) ? '' : $begin_date;
		$content['current_last_date'] = ($last_date == 'all' ) ? '' : $last_date;
		

		
		echo view('backend/newsShowpage', $content);
		
	}



}
?>