<?php

namespace App\Controllers\Backend;

use App\Controllers\BaseController;

class Backhome extends BaseController
{
    public function __construct(){
		$this->_check_login();
	}
	private function _check_login()
	{
		if( session('admin_login') != 'login' )
		{
			header('location:' . base_url('login1') );
			die();
		}
	}

    public function showBackHome(){
		// isset($_SESSION['some_name']);
        // $builder = $this->db->table("news")->orderBy('cDay', 'DESC')->limit(99);
		// $query   = $builder->get(); 
		// $results = $query->getResult();
        
        // $date["news"] =$results;
		
		return view('backend/backhome');
    }
	


}
?>