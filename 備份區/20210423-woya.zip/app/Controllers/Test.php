<?php

namespace App\Controllers;

class Test extends BaseController
{
	public function index()
	{	
        $builder = $this->db->table("news");
		$query = $builder->get();
		$results = $query->getResult();
        $date["news"] =$results;
        $i=0;
        foreach($date["news"] as $row){
            $i++;
        }
        echo $i;
        // die();
        $file = $this->request->getFile('userfile');

		return view('test');
	}
    public function ilist()
	{
		$begin_date = $this->uri->setSilent()->getSegment(4,'all');	
		$last_date = $this->uri->setSilent()->getSegment(5,'all');
		$current_page = $this->uri->setSilent()->getSegment(6,1);

		//分頁設定值
        $limit = 5;
        $data_row = ($current_page - 1) * $limit;
        $base_url_segment = 'Test/ilist'. $begin_date .'/'. $last_date;

		//列表資料
        if($begin_date != 'all') $this->db->table("news")->where('cDay >=', $begin_date);
		if($last_date != 'all') $this->db->table("news")->where('cDay <=', $last_date);
		//$query = $builder->get('news',$limit, $data_row);
		$content['news'] = $this->db->table("news")->orderBy('cDay', 'desc');

		//列表數量
        if($begin_date != 'all') $this->db->table("news")->where('cDay >=', $begin_date);
		if($last_date != 'all') $this->db->table("news")->where('cDay <=', $last_date);

        $builder = $this->db->table("news");
		$query = $builder->get();
		$results = $query->getResult();
        $date["news"] =$results;
        $newsTotal=0;
        foreach($date["news"] as $row){
            $newsTotal++;
        }
        echo $newsTotal;

        $total_rows = $newsTotal;
        // echo();
        echo "這是測試1";
		die($total_rows);

        //分頁設定
		$this->pagination->setSegment(7);
		$this->pagination->setPath($base_url_segment);
        $content['pagination_link'] = $this->pagination->makeLinks($current_page, $limit, $total_rows, 'default_full', 6);
		
        $builder = $this->db;
		$query = $builder->get('news');
		$results = $query->getResult();
		$content['news'] = $results;
		$total_rows = count($results);
    }

}

