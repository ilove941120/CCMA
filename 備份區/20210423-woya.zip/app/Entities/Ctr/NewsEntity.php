<?php namespace App\Entities;

use CodeIgniter\Entity;

class NewsEntity extends Entity
{
    protected $datamap = [
        'name' => 'cTitle'
    ];
	
    protected function getdatetime(){
        // accessor which replaces space with _ in name value
        return str_replace("-", "/", $this->attributes['cDay']);
    }
}