<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        *{
            box-sizing: border-box;
        }
        a{
            text-decoration: none;
            color:unset;
        }
        .back{
            /* display: inline; */
            width: 150px;
            padding:5px 0;
            margin:auto;
            margin-top: 10px;
            text-align:center;
            background-color:black;
            color:white;
        }
        .back:hover{
            background-color:red;
        }
        body{
            margin: 0;

        }
        .updateBlock{
            margin-top: 50px;
        }
        h1{
            text-align: center;
            background-color: brown;
            width: 500px;
            margin: auto;
            color: whitesmoke;
        }
        .aboutForm{
            width: 500px;
            background-color: antiquewhite;
            margin: auto;
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 20px;
        }
        .textBlock{
            width: 100%;
            margin: 10px 0;
        }
        .sentButton{
            width: 200px;
            margin: auto;
        }
    </style>
</head>
<body>
    <div class="updateBlock">
        <h1>公司簡介</h1>
        <form action="<?php echo $nowURL=$this->uri = current_url(true); ?>" method="post" class="aboutForm">
            <div class="updateContent">編輯內容</div>
            <textarea name="aboutText" id="aboutText" cols="30" rows="40"  class="textBlock">
                <?php echo $about[0]->aboutContent ?>
            </textarea>
            <br>
            <input type="submit" value="送出" class="sentButton">
            <input type="hidden" name="action" value="aboutText" class="sentButton">
            <a href="<?php echo base_url(); ?>/Backend/About/aboutPage" class="back">回到關於我們</a>

        </form>
    </div>
    

    
</body>
</html>