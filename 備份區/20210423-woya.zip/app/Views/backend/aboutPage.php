<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        *{
            box-sizing: border-box;
        }
        a{
            text-decoration: unset;
        }
        body{
            margin: 0;

        }
        .updateBlock{
            width: 500px;
            margin: auto;
            margin-top: 50px;
        }
        h1{
            text-align: center;
            background-color: brown;
            margin: auto;
            color: whitesmoke;
        }
        .buttonBar{
            width: 100%;
            background-color: blanchedalmond;
            height: auto;
            display: flex;
        }
        .item{
            background-color: darkblue;
            color: whitesmoke;
            padding: 10px;
            margin: 10px;
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <div class="updateBlock">
        <h1>關於我們</h1>
        <div class="buttonBar">
            <a href="<?php echo base_url() ?>/login" class="item">回到後台</a>
            <a href="<?php echo base_url(); ?>/Backend/About/aboutShow" class="item">公司簡介</a>
            <a href="<?php echo base_url(); ?>/Backend/About/aboutShowSpirit" class="item">企業精神</a>
        </div>

    </div>
    

    
</body>
</html>