<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        *{
            box-sizing: border-box;
        }
        a{
            color: unset;
            text-decoration: unset;
        }
        body{
            margin: 0;
        }
        .head{
            width: 100%;
            background-color: #c9c9fc;
            padding:10px 20px;
            display: flex;
            justify-content: space-between;
        }
        .pageTitle{
            font-size:24px;
        }
        .loginOut{
            padding:10px;
            background-color: #f1da71;
            color:#ffffff;
        }
        .content{
            width: 100%;
            height: 100vh;
            background-color: rgb(253, 248, 237);
        }
        .buttonBar{
            display: flex;
        }
        .item{
            padding: 10px;
            font-size: 24px;
            background-color: rgba(66, 0, 33, 0.712);
            margin: 10px;
            border-radius: 10px;
            letter-spacing: 2px;
            color: rgb(255, 218, 7);

        }
    </style>
</head>
<body>
    <div class="head">
        <a href="" class="pageTitle">Woya後臺管理</a>
        <a href="" class="loginOut">登出</a>
    </div>
    <div class="content">
        <div class="buttonBar">
            <div class="item">
                <a href="">關於我們</a>
            </div>
            <div class="item">
                <a href="">最新消息</a>
            </div>
        </div>
        
    </div>
    
</body>
</html>