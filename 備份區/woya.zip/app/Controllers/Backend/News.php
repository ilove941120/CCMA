<?php

namespace App\Controllers\Backend;

use App\Controllers\BaseController;

class News extends BaseController
{
	public function __construct(){
		echo "123";
		$this->_check_login();
	}
    public function show(){
		isset($_SESSION['some_name']);
        $builder = $this->db->table("news")->orderBy('cDay', 'DESC')->limit(99);
		$query   = $builder->get(); 
		$results = $query->getResult();
        
        $date["news"] =$results;
		
		return view('backend/showpage',$date);
    }
	


    public function add(){
		if(isset($_POST["action"])&&($_POST["action"]=="update")){
			$data = [
				'cTitle' => $_POST["cTitle"],
				'cDay' => $_POST["cDay"],
			];
			$builder = $this->db->table("news")->insert($data);
	        header("Location:" . base_url('Backend/Date/show'));
            die();

		}
		return view('backend/add');
    }
    public function updatePage(){
		// $i=$this->request->getGet("cID");
		// echo var_dump($i);
		// die('<br>不要理我');
		// $i=1;
		// $segments = ['Backend/Date', 'updatePage', $i];
		// echo index_page()."<br>";
		// echo site_url($segments)."<br>";
		$i=$this->uri->getSegment(4,'all');
        $builder = $this->db->table("news")->where("cID=".$i);
		$query   = $builder->get(); 
		$results = $query->getResult();
        $date["news"] =$results;

		if(isset($_POST["action"])&&($_POST["action"]=="update")){
			$data = [
				'cTitle' => $_POST["cTitle"],
				'cDay' => $_POST["cDay"],
			];
			$builder = $this->db->table("news")->where("cID=".$i)->update($data);
	        header("Location:" . base_url('Backend/Date/show'));
            die();

		}
		return view('backend/update',$date);

    }
	public function deletePage(){
		$i=$this->uri->getSegment(4,'all');
        $builder = $this->db->table("news")->where("cID=".$i);
		$query   = $builder->get(); 
		$results = $query->getResult();
        $date["news"] =$results;

		if(isset($_POST["action"])&&($_POST["action"]=="delete")){
			$builder = $this->db->table("news")->where("cID=".$i)->delete();
	        header("Location:" . base_url('Backend/Date/show'));
            die();
		}
		return view('backend/delete',$date);
    }

}
?>