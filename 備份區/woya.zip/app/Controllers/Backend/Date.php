<?php

namespace App\Controllers\Backend;

use App\Controllers\BaseController;

class Date extends BaseController
{
    public function show(){
        // $builder = $this->db->table("news")->insert($data);
		// $builder = $this->db->table("news")->delete(['cTitle' => '第一次測試']);
		// $builder = $this->db->table("news")->like('cTitle','2')->update($data1);
        $builder = $this->db->table("news")->orderBy('cDay', 'DESC')->limit(99);
		$query   = $builder->get(); 
		$results = $query->getResult();
        
        $date["news"] =$results;
		
		return view('backend/showpage',$date);
    }
    public function add(){
		if(isset($_POST["action"])&&($_POST["action"]=="update")){
			$data = [
				'cTitle' => $_POST["cTitle"],
				'cDay' => $_POST["cDay"],
			];
			$builder = $this->db->table("news")->insert($data);
	        header("Location:" . base_url('Backend/Date/show'));
            die();

		}
		return view('backend/add');
    }
    public function updatePage(){
        $builder = $this->db->table("news")->where(cID);
		$query   = $builder->get(); 
		$results = $query->getResult();
        $date["news"] =$results;
        $array = ['' => $name,]

		if(isset($_POST["action"])&&($_POST["action"]=="update")){
			$data = [
				'cTitle' => $_POST["cTitle"],
				'cDay' => $_POST["cDay"],
			];
			$builder = $this->db->table("news")->update($data);
	        header("Location:" . base_url('Backend/Date/show'));
            die();

		}
		return view('backend/update');

    }
}
?>