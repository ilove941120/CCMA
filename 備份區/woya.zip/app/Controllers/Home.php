<?php

namespace App\Controllers;

class Home extends BaseController
{
	public function index()
	{
		// 新消息
		// 查詢
		$query = $this->db->query("SELECT * FROM news WHERE cTitle LIKE '%2%'");
		// 回傳到一個陣列
		$results = $query->getResult();
		$date['news'] =$results;
		unset($results);
		// banner
		// $query1 = $this->db->query('SELECT * FROM banner_title');
		// $results1 = $query1->getResult();
		$query = $this->db->query('SELECT * FROM banner_title');
		$results = $query->getResult();
		$date['banner_title'] =$results;
		unset($results);

		// echo base_url();
		// return view('hello',$date);
		return view('welecome',$date);
		// return $results;
	}
}

