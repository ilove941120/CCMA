    
    <!-- foot -->
    <div class="foot">
        <div class="container">
            <div class="row">
                <div class="foot_top">
                    <div class="foot_logo_block"></div>
                    <div class="foot_content_block">
                        <div class="foot_content">TEL 04-8335182 FAX 04-8335183</div>
                        <div class="foot_content">E-MAIL immi.huang@gmail.com</div>
                        <div class="foot_content">彰化縣員林鎮員東路2段423巷2號</div>
                    </div>
                </div>
                 
            </div>
            <div class="row">
                <div class="foot_bottom">
                    <div class="foot_company">Copyright© 奕多國際貿易有限公司 <br class="show_RWD"> 2017.All right reserved.</div>
                    <div class="foot_make_company"><img class="gs_logo" src="img/gs_logo.png" alt=""> 網頁設計:橘野數位設計</div>
                </div>
            </div>
        </div>
    </div>
    <!-- top案紐 -->
    <div class="top_button_block">
        <a href="#" class="top_button">^</a>
    </div>
    <!-- JS top案紐 -->
    <script>
        $(".top_button_block").hide()
        $(document).scroll(function(){
            var windowScrollTop = $(window).scrollTop()
            if( windowScrollTop > 0){
                $(".top_button_block").fadeIn()
            }
            else{
                $(".top_button_block").fadeOut()
            }
        })
    </script>

</body>
</html>