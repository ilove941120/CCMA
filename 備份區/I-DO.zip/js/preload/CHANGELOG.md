# jQuery Preload Plugin CHANGELOG

## 1.0.2

* Add package.json for new jquery plugin site



## 1.0.1

* Fix `$` namespace conflict



## 1.0.0

* First stable release