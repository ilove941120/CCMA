<?php include_once("php/head.php");  ?>

<section>
    <div class="welcome_page">
        <!-- 主輪播 -->
        <div class="main_slider">
            <div class="slide_item">
                <img src="upload/main_slider.jpg" alt="">
            </div>
            <div class="slide_item">
                <img src="test_img/12528489_xxl.jpg" alt="">
            </div>
            <div class="slide_item">
                <img src="test_img/22349350_xl.jpg" alt="">
            </div>
        </div>
        <!-- JS slick 輪播 -->
        <script>
            $('.main_slider').slick({
                arrows:false,
                dots: true,
                infinite: true,
                speed: 500,
                fade: true,
                cssEase: 'linear'
            });
        </script>
        <!-- 主輪播 -->
        <!-- 關於我們 -->
        <div class="about_block">
            <div class="about_mask"></div>
            <div class="about_content_block">
                <div class="about_english_title"> <div class="line_decoration_left"></div> ABOUT US <div class="line_decoration_right"></div></div>
                <div class="about_chinese_title">關於奕多國際貿易</div>
                <div class="about_content">

                    <div class="about_text">
                        
                        有一隻活了一百萬次的貓，它死了一百萬次，也活了一百萬次。但貓一直不喜歡任何人。

                        有一次，貓是國王的貓，國王很喜歡貓，做了一個美麗的籃子，把貓放在裡面。每次國王要打扙都把貓帶在身邊。不過貓很不快樂，有一次在打扙時，貓被箭打死了，國王抱著貓，哭得好傷心、好傷心，但是貓沒有哭，貓不喜歡國王。

                        有一次，貓是漁夫的貓，漁夫很喜歡貓，每次漁夫出海補魚，都會帶著貓，不過貓很不快樂。有一次在打漁時，貓掉進海裡，漁夫趕緊拿網子把貓撈起來，不過貓已經死了。漁夫抱著牠哭得好傷心、好傷心，但是貓並沒有哭，貓不喜歡漁夫。

                        有一次，貓是馬戲團的貓。馬戲團的魔術師喜歡表演一樣魔術，就是把貓放在箱子裡把箱子和貓一起切開，然後再把箱子合起來，而貓又變回一隻活蹦亂跳的貓，不過貓很不快樂，有一次魔術師在表演這一個魔術時，不小心將貓真的切成了兩半，貓死了。魔術師抱著切成了兩半的貓，哭得好傷心、好傷心，不過貓並沒有哭，貓不喜歡馬戲團。

                        有一次，貓是老婆婆的貓，貓很不快樂，因為老婆婆喜歡靜靜的抱著貓，坐在窗前看著行人來來往往，就這樣過了一天又一天、一年又一年。有一天，貓在老婆婆的懷裡一動也不動，貓又死了，老婆抱著貓哭得好傷心、好傷心，但是貓並沒有哭，貓不喜歡老婆婆。

                        有一次，貓不是任何人的貓，貓是一隻野貓，貓很快樂，每天貓有吃不完的魚，每天都有母貓送魚來給牠吃。牠的身旁總是圍了一群美麗的母貓，不過貓並不喜歡牠們。貓每次都是驕傲的說：「我可是一隻活過一百萬次的貓喔！」

                        有一天，貓遇到了一隻白貓，白貓看都不看貓一眼，貓很生氣的走到白貓面前對白貓說：「我可是一隻活過一百萬次的貓喔！」白貓只是輕輕的「哼！」了一聲，就把頭轉開了。之後，貓每次遇到白貓，都會故意走到白貓面前說：「我可是一隻活過一百萬次的貓喔！」而白貓每次也都只是輕輕的「哼！」了一聲，就把頭轉開。

                        貓變得很不快樂，一天，貓又遇到白貓，剛開始，貓在白貓身邊獨自玩耍，後來漸漸的走到白貓身邊，輕輕的問了一句話：「我們在一起好嗎？」而白貓也輕輕的點了點頭「嗯！」了一聲，貓好高興、好高興，牠們每天都在一起，白貓生了好多小貓，貓很用心的照顧小貓們，小貓長大了，一個個離開了，貓很驕傲，因為貓知道：小貓們是一隻活過一百萬次的貓的小孩！

                        白貓老了，貓很細心的照顧著白貓，每天貓都抱著白貓說故事給白貓聽，直到睡著。一天，白貓在貓的懷裡一動也不動了，白貓死了。貓抱著白貓哭了，貓一直哭、一直哭、一直哭，直到有一天，貓不哭了，貓再也不動了，貓和白貓一起死了，貓也沒有再活過來。

                        沒有情感的活了一百萬次，並不如有愛的活了一輩子；無法體會生命的活了一百萬次，更是不如用生命付出愛的一輩子。而每個人都能體會出生命的價值嗎？我想是不盡然的，有的人無法體會出生命的價值，有的人不能享受「付出生命之愛」的感覺，我認為這都是跟貓一樣，時間上早晚的問題而已。

                        貓在活了一百萬次之後，終於讓他找到了白貓。為什麼白貓會讓貓有這麼特別的感受呢，那是因為白貓終於讓貓發現了生命的價值，這種價值就是付出你的愛，愛你的親人朋友，甚至是愛那些弱勢之人。因此貓開始享受他之前未曾領悟的生命，一輩子遠大於之前的一百萬次生命。

                        在每個人的生命裡，或多或少都會有一些讓人深刻體驗的事情，讓人慶幸此時此刻活在這世界上，讓人很清楚的了解活著的美好。我想有了這些，或許你覺得此生你已經足夠了，錯了！

                        生命中還有更深刻的體驗等著你－－那就是付出你的愛，愛你的親人朋友，甚至是愛那些弱勢之人－－若你覺得沒有，我想那可能是你還沒遇到讓你不可思議的白貓而已。或許該注意一下週遭，到處都是你的「白貓」。

                        如果你夠幸運的話，在你一生當中，你會碰到幾個握有可以打開你內心倉庫的鑰匙。但很多人終其一生，內心的倉庫卻始終未曾被開啟。其實很多人都不知道，鑰匙就在自己手上。

                        貓雖然活了一百萬次，卻從沒有真正的活過，貓一直被人捧在手掌心中，一直被人疼愛著，但他確一點都不開心，直到他開始去愛，開始去體驗人生，有了家庭、有人愛人、有了小孩，開始付出他的愛。

                        總是覺得：人其實也有可能像貓一樣！仔細想想：從出生到現在，你快樂嗎？你是否一直在找尋一種感覺、一種悸動、心靈的悸動，以便能真正的活出你的生命，好在白髮斑駁時，回憶起這一生，可以安心的對自己說：「我，沒有白活！」付出你的愛，愛你的親人朋友，甚至是愛那些弱勢之人，心中有了牽掛，即使是負荷，卻是最甜蜜的負荷，終於能甘心的過完的一生，安詳的死去。

                        我只想精采的活一次~~~ 
                    </div>
                </div>
            </div>
            
        </div>
        <!-- 關於我們 -->
        <!-- 產品展示 -->
        <div class="product_show_block">
            <div class="container">
                <div class="row">
                    <div class="product_show">
                        <a href="#" class="product_item">
                            <img src="upload/test1.jpg" alt="">
                            <div class="product_item_mask">
                                <div class="product_item_name">產品名稱</div>
                            </div>
                        </a>
                        <a href="#" class="product_item">
                            <img src="upload/test1.jpg" alt="">
                            <div class="product_item_mask">
                                <div class="product_item_name">產品名稱</div>
                            </div>
                        </a>
                        <a href="#" class="product_item">
                            <img src="upload/test1.jpg" alt="">
                            <div class="product_item_mask">
                                <div class="product_item_name">產品名稱</div>
                            </div>
                        </a>
                        <a href="#" class="product_item">
                            <img src="upload/test1.jpg" alt="">
                            <div class="product_item_mask">
                                <div class="product_item_name">產品名稱</div>
                            </div>
                        </a>
                    </div>
                    <div class="product_show_sm">
                        <a href="#" class="product_item">
                            <img src="upload/test1.jpg" alt="">
                            <div class="product_item_mask">
                                <div class="product_item_name">產品名稱</div>
                            </div>
                        </a>
                        <a href="#" class="product_item">
                            <img src="upload/test1.jpg" alt="">
                            <div class="product_item_mask">
                                <div class="product_item_name">產品名稱</div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- JS產品的寬度等於高度 -->
        <script>
            var product_width = $("product_item").width()
            $(document).ready(function(){
                $(".product_item").height(product_width)
            })
            $(window).resize(function(){
                $(".product_item").height(product_width)
            })
        </script>
        <!-- 產品展示 -->
        <!-- 公司 -->
        <div class="company_block">
            <div class="container">
                <div class="row">
                    <div class="company">
                        <a href="#" class="company_item">
                            <img src="img/logo2.gif" alt="">
                        </a>
                        <a href="#" class="company_item">
                            <img src="img/logo2.gif" alt="">
                        </a>
                        <a href="#" class="company_item">
                            <img src="img/logo2.gif" alt="">
                        </a>
                        <a href="#" class="company_item">
                            <img src="img/logo2.gif" alt="">
                        </a>
                        <a href="#" class="company_item">
                            <img src="img/logo2.gif" alt="">
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- 公司 -->
    </div>
</section>


<?php include_once("php/foot.php"); ?>