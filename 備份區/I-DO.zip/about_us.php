<?php include_once("php/head_page.php");  ?>

<section>
  <!-- 關於我們 -->
  <div class="about_us_block">
    <div class="container">
      <div class="row">
        <div class="aboutus_page_title_block">
          <div class="aboutus_english_title"> 
            <div class="line_decoration_left"></div>
            About us
            <div class="line_decoration_right"></div>
          </div>
          <div class="aboutus_chinese_title">奕多國際貿易</div>
        </div>
      </div>
      <div class="row">
        <div class="aboutus_page_content_block">
          在我為成人大學上的一堂課上，我做了一件「不可原諒的事」。

          我給全班出家庭作業，作業內容是：「在下週以前去找你愛的人，告訴他們你愛他。那些人必須是你從沒說過這句話的人。」這個作業聽來並不刁難。

          但你得明白，這群人中大部份超過三十五歲，他們在被教導表露情感是不對的那個年代成長。不能表現情感或哭泣（這是絕對禁止的！）。所以對某些人而言，這真是一個令人震驚的家庭作業。

          在我們下一堂課程開始之前，我問他們，是否有人願意，我非常希望有個女人先當志願者，就跟往常一樣。

          但這個晚上卻有個男人舉起了手，他看來深受感動而且有些緊張、害怕。他從椅子上拉開身子（他有六呎二吋高），他開始說話了：

          「老師，上禮拜你給我們這個家庭作業時，我對你非常生氣。我並不感覺有什麼人要我對他說這些話。還有，你是什麼人，竟敢教我去做這種私人的事？但當我開車回家時，我的意識開始對我說話──它告訴我，我確實知道我必須向誰說『我愛你』。

          打從五年前我的父親和我交惡了，從那時起這事就沒有真正解決。

          我們彼此避免遇見對方，除非在聖誕節或其他家庭聚會中非見面不可。儘管如此，我們還是幾乎不交談。

          所以，上星期二我回到家時，我告訴我自己，我要告訴我父親我愛他。說來很怪，但做這決定時，我胸口上的重量似乎就減輕了。

          我一回到家，就衝進房子裡告訴我太太我要做的事。她已經睡著了，但我還是吵醒了她。當我這樣告訴她時，她還沒真的起床，忽然抱緊我，打從我們結婚以來，這是她第一次看我哭。

          我們聊天、喝咖啡到半夜，感覺真棒！第二天，我一大早就精神奕奕的起床了。

          我太興奮了，所以我幾乎沒睡著。我很早就到辦公室，兩小時內做的事比從前一天做的還要多。九點我打電話給我爸，問他我下班後是否可以回去。

          他聽電話時，我只是說：『爸，今天我可以過去嗎？有些事我想告訴你。』

          我父親以暴躁的聲音回答：『現在又是什麼事？』

          我跟他保證，不會花很長的時間，最後他終於同意了。

          五點半，我到了父母家，按門鈴，祈禱我爸會出來開門。我怕是我媽來應門，而我會因此怯懦，乾脆告訴她代替算了。但幸運的是，我爸來開了門。

          我沒有浪費一丁點的時間，我一踏進門就說：『爸，我只是來告訴你，我愛你。』

          我父親似乎變了一個人。在我面前，他的臉變柔和了，皺紋消失了，他開始哭了。

          他伸手擁抱我說：『我也愛你，兒子！而我竟沒能對你這麼說！』

          這一刻如此珍貴，我一點也不想移動。

          我媽滿眼淚水的走過來。我彎下身子給她一個吻。爸和我又擁抱了一會兒，然後我離開了。

          長久以來我很少感覺這麼好過。但這不是我的重點。兩天後，我那從沒告訴我他有心臟病的爸爸，忽然發病，在醫院結束了他的一生。

          我並不知道他會如此。

          所以我要告訴全班同學的是：『你知道必須做的，就不要遲疑。如果，我遲疑著沒有告訴我爸，可能就沒有機會了！把時間拿來做你該做的，現在就做！』」
        </div>
      </div>
    </div>
  </div>
  <!-- JS產品的寬度等於高度 -->
  <script>
    var product_img_width = $("product_img").width();
    $(document).ready(function () {
      $(".product_img").height(product_img_width);
    });
    $(window).resize(function () {
      $(".product_img").height(product_img_width);
    });
  </script>
  <!-- 關於我們 -->

  <!-- 產品展示 -->
  <div class="product_show_block">
    <div class="container">
      <div class="row">
        <div class="product_show">
          <a href="#" class="product_item">
            <img src="upload/test1.jpg" alt="" />
            <div class="product_item_mask">
              <div class="product_item_name">產品名稱</div>
            </div>
          </a>
          <a href="#" class="product_item">
            <img src="upload/test1.jpg" alt="" />
            <div class="product_item_mask">
              <div class="product_item_name">產品名稱</div>
            </div>
          </a>
          <a href="#" class="product_item">
            <img src="upload/test1.jpg" alt="" />
            <div class="product_item_mask">
              <div class="product_item_name">產品名稱</div>
            </div>
          </a>
          <a href="#" class="product_item">
            <img src="upload/test1.jpg" alt="" />
            <div class="product_item_mask">
              <div class="product_item_name">產品名稱</div>
            </div>
          </a>
        </div>
        <div class="product_show_sm">
          <a href="#" class="product_item">
            <img src="upload/test1.jpg" alt="" />
            <div class="product_item_mask">
              <div class="product_item_name">產品名稱</div>
            </div>
          </a>
          <a href="#" class="product_item">
            <img src="upload/test1.jpg" alt="" />
            <div class="product_item_mask">
              <div class="product_item_name">產品名稱</div>
            </div>
          </a>
        </div>
      </div>
    </div>
  </div>
  <!-- JS產品的寬度等於高度 -->
  <script>
    var product_width = $("product_item").width();
    $(document).ready(function () {
      $(".product_item").height(product_width);
    });
    $(window).resize(function () {
      $(".product_item").height(product_width);
    });
  </script>
  <!-- 產品展示 -->
  <!-- 公司 -->
  <div class="company_block">
    <div class="container">
      <div class="row">
        <div class="company">
          <a href="#" class="company_item">
            <img src="img/logo2.gif" alt="" />
          </a>
          <a href="#" class="company_item">
            <img src="img/logo2.gif" alt="" />
          </a>
          <a href="#" class="company_item">
            <img src="img/logo2.gif" alt="" />
          </a>
          <a href="#" class="company_item">
            <img src="img/logo2.gif" alt="" />
          </a>
          <a href="#" class="company_item">
            <img src="img/logo2.gif" alt="" />
          </a>
        </div>
      </div>
    </div>
  </div>
  <!-- 公司 -->
</section>
    

<?php include_once("php/foot.php"); ?>